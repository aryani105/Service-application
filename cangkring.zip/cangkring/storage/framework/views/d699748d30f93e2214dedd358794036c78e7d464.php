
<?php $__env->startSection('title'); ?>
    Dashbaord | Edit People
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-style'); ?>
    <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h2 class="h3 mb-0 text-gray-800">Edit Data</h2>
    
  </div>
</div>

<div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>
          <div class="card">
            <div class="card-body">
              <form action="<?php echo e(route('people.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-12">
                      <label>NIK</label>
                      <input type="text" name="nik" class="form-control" value='<?php echo e($item->nik); ?>'>
                    </div>
                    <div class="col-12">
                        <label>Nama Penduduk</label>
                        <input type="text" name="people" class="form-control" value='<?php echo e($item->people); ?>'>
                      </div>
                      <div class="col-12">
                        <label>Tempat Lahir</label>
                        <input type="text" name="birth_place" class="form-control" value='<?php echo e($item->birth_place); ?>'>
                      </div>
                      <div class="col-12">
                        <label>Tanngal Lahir</label>
                        <input type="date" name="date_place" class="form-control" value='<?php echo e($item->date_place); ?>'>
                      </div>
                      <div class="col-12">
                        <label>Jenis Kelamin</label>
                        <select name="gender" class="form-control">
                          <option value="choose">-Pilih-</option>
                          <option value="Laki-laki">Laki-laki</option>
                          <option value="Perempuan">Perempuan</option>  
                        </select>
                      </div>
                      <div class="col-12">
                        <label>Desa</label>
                        <input type="text" name="address" class="form-control" value='<?php echo e($item->address); ?>'>
                      </div>
                      <div class="col-12">
                        <label>RT</label>
                        <input type="text" name="rt" class="form-control" value='<?php echo e($item->rt); ?>'>
                      </div>
                      <div class="col-12">
                        <label>RW</label>
                        <input type="text" name="rw" class="form-control" value='<?php echo e($item->rw); ?>'>
                      </div>
                      <div class="col-12">
                        <label>NO KK</label>
                        <input type="text" name="no_kk" class="form-control" value='<?php echo e($item->no_kk); ?>'>
                      </div>
                      <div class="col-12">
                        <label>Agama</label>
                        <select name="religion" class="form-control">
                          <option value="choose">-Pilih-</option>
                          <option value="Islam">Islam</option>
                          <option value="Kristen">Kristen</option>
                          <option value="Katolik">Katolik</option>
                          <option value="Hindu">Hindu</option>  
                          <option value="Budha">Budha</option>
                          <option value="Konghucu">Konghucu</option>
                        </select>
                      </div>
                      <div class="col-12">
                        <label>Status Perkawinan</label>
                        <select name="status" class="form-control">
                          <option value="choose">-Pilih-</option>
                          <option value="Kawin">Kawin</option>
                          <option value="Belum_Kawin">Belum Kawin</option>
                          <option value="cerai_hidup">Cerai Hidup</option>
                          <option value="cerai_mati">Cerai Mati</option>
                        </select>
                      </div>
                      <div class="col-12">
                        <label>Pekerjaan</label>
                        <input type="text" name="job" class="form-control" value='<?php echo e($item->job); ?>'>
                      </div>
                      <div class="col-12">
                        <label>Status</label>
                        <select name="information" class="form-control">
                            <option value="ADA">ADA</option>
                            <option value="MENINGGAL">MENINGGAL</option>
                            <option value="PINDAH">PINDAH</option>
                        </select>
                      </div>
                  </div>
                  <div class="row mt-3">
                    <div class="col-12 text-right">
                      <button type="submit" class="btn btn-success px-5">
                        Simpan Data
                      </button>
                    </div>
                  </div>
              </form>
            </div>
          </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cangkring\resources\views/pages/people/edit.blade.php ENDPATH**/ ?>