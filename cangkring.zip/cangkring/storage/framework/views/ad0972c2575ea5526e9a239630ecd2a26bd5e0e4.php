
<?php $__env->startSection('title'); ?>
    DATA PENDATANG
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-style'); ?>
<link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
    <div class="col-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
<a href="/dashboard/comer/create" class="btn btn-sm btn-primary">Tambah Pendatang +</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>NIK</th>
                                <th>Nama</th>
                                <th>Jenis Kelamin</th>
                                <th>Tanggal</th>
                                <th>Pelapor</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-script'); ?>
        <!-- Page level plugins -->
        <script src="/vendor/datatables/jquery.dataTables.min.js"></script>
        <script src="/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script>
    var datatable=$('#dataTable').DataTable({
        processing:true,
        severSide:true,
        ordering:true,
        ajax: {
            url:'<?php echo url()->current(); ?>',
        },
        columns:[
            { data:'nik', name:'nik'},
            { data:'name', name:'name'}, 
            { data:'gender', name:'gender'}, 
            { data:'date', name:'date'},
            { data:'informant', name:'informant'},
            {
                 data:'action', name:'action',
                 orderable:false,
                 searchable:false,
                 width:'150px'
            }
        ]
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cangkring\resources\views/pages/comer/index.blade.php ENDPATH**/ ?>