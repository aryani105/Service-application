
<?php $__env->startSection('title'); ?>
    Dashbaord | Edit Data
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-style'); ?>
    <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h2 class="h3 mb-0 text-gray-800">Edit Data</h2>
    
  </div>
</div>

<div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>
          <div class="card">
            <div class="card-body">
              <form action="<?php echo e(route('comer.update', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-12">
                      <label>NIK</label>
                      <input type="text" name="nik" class="form-control" value='<?php echo e($item->nik); ?>'>
                    </div>
                    <div class="col-12">
                      <label>Nama</label>
                      <input type="text" name="name" class="form-control" value='<?php echo e($item->name); ?>'>
                    </div>
                    <div class="col-12">
                      <label>Jenis Kelamin</label>
                      <select name="gender" class="form-control">
                        <option value="choose">-Pilih-</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>  
                      </select>
                    </div>
                    <div class="col-12">
                        <label>Tanggal</label>
                        <input type="date" name="date" class="form-control" value='<?php echo e($item->date); ?>'>
                      </div>
                      <div class="col-12">
                        <label>Pelapor</label>
                        <input type="text" name="informant" class="form-control" value='<?php echo e($item->informant); ?>'>
                      </div>
                  <div class="row mt-3">
                    <div class="col-12 text-right">
                      <button type="submit" class="btn btn-success px-5">
                        Simpan Data
                      </button>
                    </div>
                  </div>
              </form>
            </div>
          </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/pages/comer/edit.blade.php ENDPATH**/ ?>