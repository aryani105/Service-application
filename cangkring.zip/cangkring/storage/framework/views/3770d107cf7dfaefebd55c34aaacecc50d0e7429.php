
<?php $__env->startSection('title'); ?>
    Dashbaord | Buat Data
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-style'); ?>
    <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h2 class="h3 mb-0 text-gray-800">Buat Data</h2>
    
  </div>
</div>

<div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        <?php endif; ?>
          <div class="card">
            <div class="card-body">
              <form action="<?php echo e(route('move.store')); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-12">
                      <label>NIK</label>
                      <input type="text" name="nik" class="form-control" required>
                    </div>
                    <div class="col-12">
                      <label>Nama</label>
                      <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-12">
                        <label>Tanggal</label>
                        <input type="date" name="date" class="form-control" required>
                      </div>
                      <div class="col-12">
                        <label>Alasan</label>
                        <input type="text" name="reason" class="form-control" required>
                      </div>
                  </div>
                  <div class="row mt-3">
                    <div class="col-12 text-right">
                      <button type="submit" class="btn btn-success px-5">
                        Simpan Data
                      </button>
                    </div>
                  </div>
              </form>
            </div>
          </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/pages/move/create.blade.php ENDPATH**/ ?>