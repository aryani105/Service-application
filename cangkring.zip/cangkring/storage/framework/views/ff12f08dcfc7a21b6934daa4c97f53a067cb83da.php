
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Content Row -->
    <div class="row">
        <div class="col-12" id="GFG">
            <center>

                <h2>PEMERINTAH KABUPATEN CIREBON</h2>
                <h3>KECAMATAN PLERED
                    <br>DESA CANGKRING</h3>
                <p>________________________________________________________________________</p>
            </center>
        
            <center>
                <h4>
                    <u>SURAT KETARANGAN LAHIR</u>
                </h4>
                <h4>No Surat : 
                    
                </h4>
            </center>
            <p>Yang bertandatangan dibawah ini Kepala Desa <u>Cangkring</u>, Kecamatan Plered, Kabupaten Cirebon, dengan ini menerangkan
                bahawa :</P>
            <table>
                <tbody>
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><?php echo e($data->name); ?>

                            
                        </td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td>:</td>
                        <td><?php echo e($data->birth_date); ?>

                            
                        </td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td>:</td>
                        <td><?php echo e($data->gender); ?>

                            
                        </td>
                    </tr>
            <p>Adalah anak dari:</p>       
                    <tr>
                        <td>Keluarga</td>
                        <td>:</td>
                        <td><?php echo e($data->family); ?>

                            
                        </td>
                    </tr>
                </tbody>
            </table>
            <p>Demikian Surat ini dibuat, agar dapat digunakan sebagai mana mestinya.</P>
            <br>
            <br>
            <br>
            <br>
            <br>
            <p align="right">
             
                
                <br> KEPALA DESA CANGKRING
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>(....................................................)
            </p>
        </div>
          
        <div class="col-12 text-center"><input type="button" class="btn btn-primary" value="Print" onclick="printDiv()"> </div>
<!-- Script to print the content of a div -->

    </div>
<!-- Content Row -->
</div>

<script>
    function printDiv() {
        var divContents = document.getElementById("GFG").innerHTML;
        var a = window.open('', '', 'height=500, width=500');
        a.document.write('<html>');
        a.document.write('<body >');
        a.document.write(divContents);
        a.document.write('</body></html>');
        a.document.close();
        a.print();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/pages/print-lahir.blade.php ENDPATH**/ ?>