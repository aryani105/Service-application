<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; APLIKASI DATA PENDUDUK 2022</span>
        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\blog\resources\views/includes/footer-dashboard.blade.php ENDPATH**/ ?>