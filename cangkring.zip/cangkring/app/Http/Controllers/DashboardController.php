<?php

namespace App\Http\Controllers;
use App\people;
use App\kk;
use App\birth;
use App\Dead;
use App\comer;
use App\move;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
      $people = people :: count();
      $kk = kk :: count();
      $birth = birth :: count();
      $dead = dead :: count();
      $comer = comer :: count();
      $move = move :: count();
        return view('pages.dashboard', compact('people', 'kk', 'birth', 'dead', 'comer', 'move'));
    }
    public function print_dom($id)
    {
        $data = People::find($id);
        return view('pages.print-dom',compact('data'));
    }
    public function print_lahir($id)
    {
        $data = Birth::find($id);
        return view('pages.print-lahir',compact('data'));
    }
    public function print_meninggal($id)
    {
        $data = Dead::find($id);
        return view('pages.print-meninggal',compact('data'));
    }   
     public function print_datang($id)
    {
        $data = Comer::find($id);
        return view('pages.print-datang',compact('data'));
    }
    public function print_pindah($id)
    {
        $data = Move::find($id);
        return view('pages.print-pindah',compact('data'));
    }
    public function logout()
    {
        auth()->logout();
        return redirect('/');
    }
}
