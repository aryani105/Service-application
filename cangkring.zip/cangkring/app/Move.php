<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Move extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'nik', 'name', 'date', 'reason'
    ];
    protected $hidden = [

    ];
}
