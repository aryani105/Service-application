<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Dead extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'nik', 'name', 'date', 'cause'
    ];
    protected $hidden = [

    ];
}
