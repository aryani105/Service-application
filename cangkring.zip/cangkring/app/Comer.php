<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Comer extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'nik', 'name','gender', 'date', 'informant'
    ];
    protected $hidden = [

    ];
}
