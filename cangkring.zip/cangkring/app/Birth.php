<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Birth extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'name', 'birth_date', 'gender', 'family'
    ];
    protected $hidden = [

    ];
}
