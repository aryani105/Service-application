<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Kk extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'no_kk', 'head_of_family', 'address', 'member_kk'
    ];
    protected $hidden = [

    ];
}
