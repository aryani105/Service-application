<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function(){
    return redirect('dashboard');
});
Route::prefix('dashboard')->middleware('auth')->group(function() {
    Route::get('/', 'DashboardController@index')->name('dashboard');
    Route::get('/print-dom/{id}', 'DashboardController@print_dom')->name('print-dom');
    Route::get('/print-lahir/{id}', 'DashboardController@print_lahir')->name('print-lahir');
    Route::get('/print-meninggal/{id}', 'DashboardController@print_meninggal')->name('print-meninggal');
    Route::get('/print-datang/{id}', 'DashboardController@print_datang')->name('print-datang');
    Route::get('/print-pindah/{id}', 'DashboardController@print_pindah')->name('print-pindah');
    Route::get('logout', 'DashboardController@logout')->name('logout');
    Route::resource('people','PeopleController');
    Route::resource('kk','KkController');
    Route::resource('birth','BirthController');
    Route::resource('dead','DeadController');
    Route::resource('comer','ComerController');
    Route::resource('move','MoveController');

    
});

Auth::routes();