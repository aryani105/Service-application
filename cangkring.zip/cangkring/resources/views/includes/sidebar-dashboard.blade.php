<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/">
        <div class="sidebar-brand-icon rotate-n-40">
            <i class="fas fa-envelope-square"></i>
        </div>
        <div class="sidebar-brand-text mx-3">DESA CANGKRING</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="/">
            <i class="fas fa-home"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->


    <!-- Nav menu kelola data-->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-cog"></i>
            <span>Kelola Data</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="/dashboard/people">Data Penduduk</a>
                <a class="collapse-item" href="/dashboard/kk">Data Kartu Keluarga</a>
            </div>
        </div>
    </li>
    {{-- akhir nav menu kelola data --}}
    <!-- Nav Item - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#CollapseTwo"
            aria-expanded="true" aria-controls="CollapseTwo">
            <i class="fas fa-fw fa-wrench"></i>
            <span>Sirkulasi Penduduk</span>
        </a>
        <div id="CollapseTwo" class="collapse" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="/dashboard/birth">Data Lahir</a>
                <a class="collapse-item" href="/dashboard/dead">Data Meninggal</a>
                <a class="collapse-item" href="/dashboard/comer">Data Pendatang</a>
                <a class="collapse-item" href="/dashboard/move">Data Pindah</a>
            </div>
        </div>
    </li>
   
</li>

</ul>