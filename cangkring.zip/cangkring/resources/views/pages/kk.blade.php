<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class People extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'kk', 'nik', 'birth_place', 'date_place', 'gender', 'address', 'rt', 'rw','no_kk', 'religion', 'status', 'job', 'information'
    ];
    protected $hidden = [

    ];
}
