@extends('layouts.dashboard')
@section('title')
    DATA KK
@endsection
@push('addon-style')
<link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
@endpush
@section('content')
<div class="container-fluid">
<div class="row">
    <div class="col-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
<a href="/dashboard/kk/create" class="btn btn-sm btn-primary">Tambah Data</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>NO KK</th>
                                <th>Kepala Keluarga</th>
                                <th>Alamat</th>
                                <th>Anggota KK</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
@endsection
@push('addon-script')
        <!-- Page level plugins -->
        <script src="/vendor/datatables/jquery.dataTables.min.js"></script>
        <script src="/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script>
    var datatable=$('#dataTable').DataTable({
        processing:true,
        severSide:true,
        ordering:true,
        ajax: {
            url:'{!! url()->current()!!}',
        },
        columns:[
            { data:'no_kk', name:'no_kk'},
            { data:'head_of_family', name:'head_of_family'}, 
            { data:'address', name:'address'},
            { data:'member_kk', name:'member_kk'},
            {
                 data:'action', name:'action',
                 orderable:false,
                 searchable:false,
                 width:'150px'
            }
        ]
    });
</script>
@endpush