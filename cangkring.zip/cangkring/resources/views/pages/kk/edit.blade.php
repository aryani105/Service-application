@extends('layouts.dashboard')
@section('title')
    Dashbaord | Edit Data
@endsection
@push('addon-style')
    <link href="/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
@endpush
@section('content')
<div class="container-fluid">
  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h2 class="h3 mb-0 text-gray-800">Edit Data</h2>
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
  </div>
</div>

<div class="container-fluid">
    <div class="row">
      <div class="col-12">
        @if($errors->any())
          <div class="alert alert-danger">
            <ul>
              @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @endif
          <div class="card">
            <div class="card-body">
              <form action="{{ route('kk.update', $item->id) }}" method="POST" enctype="multipart/form-data">
                  @method('PUT')
                @csrf
                  <div class="row">
                    <div class="col-12">
                      <label>NO KK</label>
                      <input type="text" name="no_kk" class="form-control" value='{{$item->no_kk}}'>
                    </div>
                    <div class="col-12">
                        <label>Kepala Keluarga</label>
                        <input type="text" name="head_of_family" class="form-control" value='{{$item->head_of_family}}'>
                      </div>
                      <div class="col-12">
                        <label>Alamat</label>
                        <input type="text" name="address" class="form-control" value='{{$item->address}}'>
                      </div>
                      <div class="col-12">
                        <label>Anggota KK</label>
                        <input type="text" name="member_kk" class="form-control" value='{{$item->member_kk}}'>
                      </div>
                  </div>
                  <div class="row mt-3">
                    <div class="col-12 text-right">
                      <button type="submit" class="btn btn-success px-5">
                        Simpan Data
                      </button>
                    </div>
                  </div>
              </form>
            </div>
          </div>
      </div>
    </div>
</div>
@endsection

